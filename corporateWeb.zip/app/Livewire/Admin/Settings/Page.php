<?php

declare(strict_types=1);

namespace App\Livewire\Admin\Settings;

use Livewire\Component;

class Page extends Component
{
    public function render()
    {
        return view('livewire.admin.settings.page');
    }
}

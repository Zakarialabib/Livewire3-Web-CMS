<svg {{ $attributes }} viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M12 2C6.486 2 2 6.486 2 12C2 17.514 6.486 22 12 22C17.514 22 22 17.514 22 12C22 6.486 17.514 2 12 2ZM12 16C10.895 16 10 15.105 10 14C10 12.895 10.895 12 12 12C13.105 12 14 12.895 14 14C14 15.105 13.105 16 12 16ZM12 8C11.447 8 11 7.553 11 7C11 6.447 11.447 6 12 6C12.553 6 13 6.447 13 7C13 7.553 12.553 8 12 8Z"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
</svg>

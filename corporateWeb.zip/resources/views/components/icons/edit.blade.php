<svg {{ $attributes }} viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M12 20.25C16.1421 20.25 19.75 16.6421 19.75 12.5C19.75 8.35786 16.1421 4.75 12 4.75C7.85786 4.75 4.25 8.35786 4.25 12.5C4.25 16.6421 7.85786 20.25 12 20.25Z"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M12 14.25V17.25"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M12 8.25V12.25"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M9.75 10.5H14.25"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
</svg>
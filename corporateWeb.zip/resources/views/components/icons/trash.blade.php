<svg {{ $attributes }} viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M3 6L5 6M5 6L5 19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19L19 6M5 6H19M10 11V17M14 11V17M10 11H14"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
</svg>
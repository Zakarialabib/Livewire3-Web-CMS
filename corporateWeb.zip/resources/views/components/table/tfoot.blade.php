<tfoot class="divide-y divide-zinc-200 bg-gray-100 text-black">
    {{ $slot }}
</tfoot>

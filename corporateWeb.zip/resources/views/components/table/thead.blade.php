<thead class="bg-gray-100 dark:bg-eval-1 text-black dark:text-white">
    <tr class="text-xs text-gray-500 text-left">
        {{ $slot }}
    </tr>
</thead>
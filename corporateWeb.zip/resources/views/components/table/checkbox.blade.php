<div class="flex items-center">
    <input type="checkbox" class="form-checkbox" wire:model.live="selected" value="{{ $value }}" />
    <span class="ml-2 text-sm text-gray-600">{{ $label }}</span>
</div>

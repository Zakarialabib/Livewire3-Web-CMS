<td {{ $attributes->merge([
    'class' => 'p-2 text-left text-gray-800',
]) }}>
    {{ $slot }}
</td>
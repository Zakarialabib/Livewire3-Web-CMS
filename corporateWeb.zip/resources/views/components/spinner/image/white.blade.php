<img src="{{ asset('images/spinner-white.svg') }}" class="w-6 h-6 animate-spin" />

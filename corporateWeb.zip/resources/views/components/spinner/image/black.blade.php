<img src="{{ asset('images/spinner-black.svg') }}" class="w-6 h-6 animate-spin" />

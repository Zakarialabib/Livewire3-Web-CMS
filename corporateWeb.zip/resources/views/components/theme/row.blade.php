<!-- resources/views/components/row.blade.php -->
@props([''])
<div {{ $attributes->merge(['class' => "flex flex-wrap -mx-4 "]) }}>
    {{-- {{ $slot }} --}}
</div>

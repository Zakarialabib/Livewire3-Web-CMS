{{-- resources/views/components/x-menu-widget.blade.php --}}
<div class="menu-widget-item">
    <div class="menu-widget-content">
        {{ $slot }}
    </div>
</div>

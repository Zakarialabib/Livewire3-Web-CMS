<!-- resources/views/components/logo.blade.php -->
<img {{ $attributes->merge(['class' => 'h-12']) }}>

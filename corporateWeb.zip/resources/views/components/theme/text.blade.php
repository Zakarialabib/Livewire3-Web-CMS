<!-- resources/views/components/text.blade.php -->
@props(['content'])

<div {{ $attributes }}>
    {!! $content !!}
</div>

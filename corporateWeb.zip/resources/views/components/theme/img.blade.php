
<!-- resources/views/components/img.blade.php -->
<img {{ $attributes->merge(['class' => 'h-12']) }}>

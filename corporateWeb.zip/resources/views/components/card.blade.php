<div class="flex flex-col justify-center items-center bg-white">
    <div class="w-full mt-2 py-2 px-4 shadow-md overflow-hidden sm:rounded-lg">
        {{ $slot }}
    </div>
</div>

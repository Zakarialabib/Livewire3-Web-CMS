<div class="alert alert-success alert-dismissible validation" style="display: none;">
    <button type="button" class="close alert-close">&times;</button>
    <p class="text-left"></p>
</div>
<div class="alert alert-danger alert-dismissible validation" style="display: none;">
    <button type="button" class="close alert-close">&times;</button>
    <ul class="text-left">
    </ul>
</div>
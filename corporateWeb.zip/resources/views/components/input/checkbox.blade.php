<div class="flex rounded-md shadow-sm">
    <input {{ $attributes }}
        type="checkbox"
        class="form-checkbox border-gray-300 block w-5 h-5 ease-linear transition-all duration-150 sm:text-sm sm:leading-5"
    />
</div>

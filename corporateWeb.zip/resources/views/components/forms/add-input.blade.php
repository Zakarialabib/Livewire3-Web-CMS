
<div class="mt-1 flex rounded-md shadow-sm">
	<span class="inline-flex items-center px-3 rounded-l-md border border-r-0 border-zinc-300 bg-zinc-50 text-gray-500 text-sm">
		{{$adon}}
	</span>
	{{$slot}}
</div>
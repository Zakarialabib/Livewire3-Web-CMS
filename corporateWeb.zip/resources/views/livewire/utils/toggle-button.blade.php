<div>
    <x-toggle-switch name="status" wire:model.live="status" class="text-white" id="{{$uniqueId}}" checked="{{$status}}"/>
</div>

  
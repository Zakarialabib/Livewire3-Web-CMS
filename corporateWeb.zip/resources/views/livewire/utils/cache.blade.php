<div>
    <button type="submit" wire:loading.attr="disabled" wire:click.throttle="onClearCache">
        {{ __('Clear all Cache') }}
    </button>
</div>

@livewireScriptConfig 

<script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.min.js"></script>

<x-livewire-alert::scripts />

@stack('scripts')
